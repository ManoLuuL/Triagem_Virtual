﻿
namespace InicioTriagem
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.maskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.VomitoS = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.ProbRecent = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.dorseve = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.Dormord = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.Dorprec = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.Dorpleu = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.Pulso = new System.Windows.Forms.RadioButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.Choque = new System.Windows.Forms.RadioButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.Respi = new System.Windows.Forms.RadioButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.Dispneia = new System.Windows.Forms.RadioButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.Cfrio = new System.Windows.Forms.RadioButton();
            this.label31 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.NDURG = new System.Windows.Forms.RadioButton();
            this.PCURG = new System.Windows.Forms.RadioButton();
            this.URG = new System.Windows.Forms.RadioButton();
            this.MTURG = new System.Windows.Forms.RadioButton();
            this.ERME = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Aquamarine;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(7, 666);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 31);
            this.button1.TabIndex = 0;
            this.button1.Text = "VOLTAR";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Data  de Entrada:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(160, 11);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(106, 21);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nome:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(71, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(297, 23);
            this.textBox1.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(374, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "Sexo:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Masculino ",
            "Femenino",
            "Prefiro não informar"});
            this.comboBox1.Location = new System.Drawing.Point(424, 54);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(128, 21);
            this.comboBox1.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Idade:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(133, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(169, 18);
            this.label6.TabIndex = 13;
            this.label6.Text = "Data de Nascimento:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(558, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 18);
            this.label7.TabIndex = 15;
            this.label7.Text = "Estado Civil:";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Solteiro(a)",
            "Casado(a)",
            "Divorciado(a)",
            "Viúvo(a)"});
            this.comboBox2.Location = new System.Drawing.Point(665, 56);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(678, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "Telefone:";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(760, 95);
            this.maskedTextBox1.Mask = "(99)0000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox1.TabIndex = 18;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(761, 143);
            this.maskedTextBox2.Mask = "(99)00000-0000";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox2.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(679, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 18);
            this.label9.TabIndex = 20;
            this.label9.Text = "Celular:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(422, 96);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 18);
            this.label10.TabIndex = 21;
            this.label10.Text = "Naturalidade:";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Araçatuba",
            "Araçoiaba da Serra",
            "Aramina",
            "Arandu",
            "Arapeí",
            "Araraquara",
            "Araras",
            "Arco-Íris",
            "Arealva",
            "Areias",
            "Areiópolis",
            "Ariranha",
            "Artur Nogueira",
            "Arujá",
            "Aspásia",
            "Assis",
            "Atibaia",
            "Auriflama",
            "Avaí",
            "Avanhandava",
            "Avaré",
            "Adamantina",
            "Adolfo",
            "Aguaí",
            "Águas da Prata",
            "Águas de Lindóia",
            "Águas de Santa Bárbara",
            "Águas de São Pedro",
            "Agudos",
            "Alambari",
            "Alfredo Marcondes",
            "Altair",
            "Altinópolis",
            "Alto Alegre",
            "Alumínio",
            "Álvares Florence",
            "Álvares Machado",
            "Álvaro de Carvalho",
            "Alvinlândia",
            "Americana",
            "Américo Brasiliense",
            "Américo de Campos",
            "Amparo",
            "Analândia",
            "Andradina",
            "Angatuba",
            "Anhembi",
            "Anhumas",
            "Aparecida",
            "Aparecida d’Oeste",
            "Apiaí",
            "Araçariguama",
            "Bady Bassitt",
            "Barbosa",
            "Bariri",
            "Barra Bonita",
            "Barra do Chapéu",
            "Barra do Turvo",
            "Barretos",
            "Barrinha",
            "Barueri",
            "Bastos",
            "Batatais",
            "Bauru",
            "Bebedouro",
            "Bento de Abreu",
            "Bernardino de Campos",
            "Balbinos",
            "Bálsamo",
            "Bananal",
            "Barão de Antonina",
            "Bertioga",
            "Bilac",
            "Birigui",
            "Biritibamirim",
            "Boa Esperança do Sul",
            "Bocaina",
            "Bofete",
            "Boituva",
            "Bom Jesus dos Perdões",
            "Bom Sucesso de Itararé",
            "Borá",
            "Boracéia",
            "Borborema",
            "Borebi",
            "Botucatu",
            "Bragança Paulista",
            "Braúna",
            "Brejo Alegre",
            "Brodowski",
            "Brotas",
            "Buri",
            "Buritama",
            "Buritizal",
            "Cabrália Paulista",
            "Cabreúva",
            "Cedral",
            "Cerqueira César",
            "Cerquilho",
            "Cesário Lange",
            "Charqueada",
            "Chavantes",
            "Clementina",
            "Colina",
            "Colômbia",
            "Conchal",
            "Conchas",
            "Cordeirópolis",
            "Coroados",
            "Coronel Macedo",
            "Corumbataí",
            "Cosmópolis",
            "Caçapava",
            "Cachoeira Paulista",
            "Caconde",
            "Cafelândia",
            "Caiabu",
            "Caieiras",
            "Caiuá",
            "Cajamar",
            "Cajati",
            "Cajobi",
            "Cajuru",
            "Campina do Monte Alegre",
            "Campinas",
            "Campo Limpo Paulista",
            "Campos do Jordão",
            "Campos Novos Paulista",
            "Cananéia",
            "Canas",
            "Cândido Mota",
            "Cândido Rodrigues",
            "Canitar",
            "Capão Bonito",
            "Capela do Alto",
            "Capivari",
            "Caraguatatuba",
            "Carapicuíba",
            "Cardoso",
            "Casa Branca",
            "Cássia dos Coqueiros",
            "Castilho",
            "Catanduva",
            "Catiguá",
            "Cosmorama",
            "Cotia",
            "Cravinhos",
            "Cristais Paulista",
            "Cruzália",
            "Cruzeiro",
            "Cubatão",
            "Cunha",
            "Descalvado",
            "Diadema",
            "Dirce Reis",
            "Divinolândia",
            "Dobrada",
            "Dois Córregos",
            "Dolcinópolis",
            "Dourado",
            "Dracena",
            "Duartina",
            "Dumont",
            "Echaporã",
            "Eldorado",
            "Elias Fausto",
            "Elisiário",
            "Embaúba",
            "Embu",
            "Embu-Guaçu",
            "Emilianópolis",
            "Engenheiro Coelho",
            "Espírito Santo do Pinhal",
            "Espírito Santo do Turvo",
            "Estiva Gerbi",
            "Estrela do Norte",
            "Estrela d’Oeste",
            "Euclides da Cunha Paulista",
            "F[editar | editar código-fonte]",
            "Fartura",
            "Fernando Prestes",
            "Fernandópolis",
            "Fernão",
            "Ferraz de Vasconcelos",
            "Flora Rica",
            "Floreal",
            "Flórida Paulista",
            "Florínea",
            "Franca",
            "Francisco Morato",
            "Franco da Rocha",
            "Gabriel Monteiro",
            "Gália",
            "Garça",
            "Gastão Vidigal",
            "Gavião Peixoto",
            "General Salgado",
            "Getulina",
            "Glicério",
            "Guaiçara",
            "Guaimbê",
            "Guaíra",
            "Guapiaçu",
            "Guapiara",
            "Guará",
            "Guaraçaí",
            "Guaraci",
            "Guarani d’Oeste",
            "Guarantã",
            "Guararapes",
            "Guararema",
            "Guaratinguetá",
            "Guareí",
            "Guariba",
            "Guarujá",
            "Guarulhos",
            "Guatapará",
            "Guzolândia",
            "Herculândia",
            "Holambra",
            "HortolândiaI",
            "Iacanga",
            "Iacri",
            "Iaras",
            "Itaóca",
            "Itapecerica da Serra",
            "Itapetininga",
            "Itapeva",
            "Itapevi",
            "Itapira",
            "Itapirapuã Paulista",
            "Itápolis",
            "Itaporanga",
            "Itapuí",
            "Itapura",
            "Itaquaquecetuba",
            "Itararé",
            "Itariri",
            "Itatiba",
            "Ibaté",
            "Ibirá",
            "Ibirarema",
            "Ibitinga",
            "Ibiúna",
            "Icém",
            "Iepê",
            "Igaraçu do Tietê",
            "Igarapava",
            "Igaratá",
            "Iguape",
            "Ilha Comprida",
            "Ilha Solteira",
            "Ilhabela",
            "Indaiatuba",
            "Indiana",
            "Indiaporã",
            "Inúbia Paulista",
            "Ipaussu",
            "Iperó",
            "Ipeúna",
            "Ipiguá",
            "Iporanga",
            "Ipuã",
            "Iracemápolis",
            "Irapuã",
            "Irapuru",
            "Itaberá",
            "Itaí",
            "Itajobi",
            "Itaju",
            "Itanhaém",
            "Itatinga",
            "Itirapina",
            "Itirapuã",
            "Itobi",
            "Itu",
            "Itupeva",
            "Ituverava",
            "Jaborandi",
            "Jaboticabal",
            "Jacareí",
            "Jaci",
            "Jacupiranga",
            "Jaguariúna",
            "Jales",
            "Jambeiro",
            "Jandira",
            "Jardinópolis",
            "Jarinu",
            "Jaú",
            "Jeriquara",
            "Joanópolis",
            "João Ramalho",
            "José Bonifácio",
            "Júlio Mesquita",
            "Jumirim",
            "Jundiaí",
            "Junqueirópolis",
            "Juquiá",
            "Juquitiba",
            "Lagoinha",
            "Laranjal Paulista",
            "Lavínia",
            "Lavrinhas",
            "Leme",
            "Lençóis Paulista",
            "Limeira",
            "Lindóia",
            "Lins",
            "Lorena",
            "Lourdes",
            "Louveira",
            "Lucélia",
            "Lucianópolis",
            "Luís Antônio",
            "Luiziânia",
            "Lupércio",
            "Lutécia",
            "Macatuba",
            "Macaubal",
            "Macedônia",
            "Monte Alegre do Sul",
            "Monte Alto",
            "Monte Aprazível",
            "Monte Azul Paulista",
            "Monte Castelo",
            "Monte Mor",
            "Monteiro Lobato",
            "Morro Agudo",
            "Morungaba",
            "Motuca",
            "Murutinga do Sul",
            "Magda",
            "Mairinque",
            "Mairiporã",
            "Manduri",
            "Marabá Paulista",
            "Maracaí",
            "Marapoama",
            "Mariápolis",
            "Marília",
            "Marinópolis",
            "Martinópolis",
            "Matão",
            "Mauá",
            "Mendonça",
            "Meridiano",
            "Mesópolis",
            "Miguelópolis",
            "Mineiros do Tietê",
            "Mira Estrela",
            "Miracatu",
            "Mirandópolis",
            "Mirante do Paranapanema",
            "Mirassol",
            "Mirassolândia",
            "Mococa",
            "Mogi das Cruzes",
            "Mogi Guaçu",
            "Mogi Mirim",
            "Mombuca",
            "Monções",
            "Mongaguá",
            "Nantes",
            "Narandiba",
            "Nova Granada",
            "Nova Guataporanga",
            "Nova Independência",
            "Nova Luzitânia",
            "Nova Odessa",
            "Novais",
            "Novo Horizonte",
            "Nuporanga",
            "Natividade da Serra",
            "Nazaré Paulista",
            "Neves Paulista",
            "Nhandeara",
            "Nipoã",
            "Nova Aliança",
            "Nova Campina",
            "Nova Canaã Paulista",
            "Nova Castilho",
            "Nova Europa",
            "Ocauçu",
            "Óleo",
            "Orindiúva",
            "Orlândia",
            "Osasco",
            "Oscar Bressane",
            "Osvaldo Cruz",
            "Ourinhos",
            "Ouro Verde",
            "Ouroeste",
            "Olímpia",
            "Onda Verde",
            "Oriente",
            "Pacaembu",
            "Palestina",
            "Palmares Paulista",
            "Palmeira d’Oeste",
            "Palmital",
            "Panorama",
            "Paraguaçu Paulista",
            "Paraibuna",
            "Paraíso",
            "Paranapanema",
            "Paranapuã",
            "Platina",
            "Poá",
            "Poloni",
            "Pompeia",
            "Pongaí",
            "Pontal",
            "Pontalinda",
            "Pontes Gestal",
            "Populina",
            "Porangaba",
            "Porto Feliz",
            "Porto Ferreira",
            "Potim",
            "Potirendaba",
            "Pracinha",
            "Parapuã",
            "Pardinho",
            "Pariquera-Açu",
            "Parisi",
            "Patrocínio Paulista",
            "Paulicéia",
            "Paulínia",
            "Paulistânia",
            "Paulo de Faria",
            "Pederneiras",
            "Pedra Bela",
            "Pedranópolis",
            "Pedregulho",
            "Pedreira",
            "Pedrinhas Paulista",
            "Pedro de Toledo",
            "Penápolis",
            "Pereira Barreto",
            "Pereiras",
            "Peruíbe",
            "Piacatu",
            "Piedade",
            "Pilar do Sul",
            "Pindamonhangaba",
            "Pindorama",
            "Pinhalzinho",
            "Piquerobi",
            "Piquete",
            "Piracaia",
            "Piracicaba",
            "Piraju",
            "Pirajuí",
            "Pirangi",
            "Pirapora do Bom Jesus",
            "Pirapozinho",
            "Pirassununga",
            "Piratininga",
            "Pitangueiras",
            "Planalto",
            "Quadra",
            "Quatá",
            "Queiroz",
            "Queluz",
            "Quintana",
            "Pradópolis",
            "Praia Grande",
            "Pratânia",
            "Presidente Alves",
            "Presidente Bernardes",
            "Presidente Epitácio",
            "Presidente Prudente",
            "Presidente Venceslau",
            "Promissão",
            "Rafard",
            "Rancharia",
            "Ribeirão Corrente",
            "Ribeirão do Sul",
            "Ribeirão dos Índios",
            "Ribeirão Grande",
            "Ribeirão Pires",
            "Ribeirão Preto",
            "Rifaina",
            "Rincão",
            "Rinópolis",
            "Rio Claro",
            "Redenção da Serra",
            "Regente Feijó",
            "Reginópolis",
            "Registro",
            "Restinga",
            "Ribeira",
            "Ribeirão Bonito",
            "Ribeirão Branco",
            "Rio das Pedras",
            "Rio Grande da Serra",
            "Riolândia",
            "Riversul",
            "Rosana",
            "Roseira",
            "Rubiácea",
            "Rubinéia",
            "Sabino",
            "Sagres",
            "Sales",
            "Sales Oliveira",
            "Salesópolis",
            "Salmourão",
            "Saltinho",
            "Salto",
            "Salto de Pirapora",
            "Salto Grande",
            "Serra Negra",
            "Serrana",
            "Sertãozinho",
            "Sete Barras",
            "Severínia",
            "Silveiras",
            "Socorro",
            "Sorocaba",
            "Sud Mennucci",
            "Sumaré",
            "Suzanápolis",
            "Suzano",
            "Sandovalina",
            "Santa Adélia",
            "Santa Albertina",
            "Santa Bárbara d’Oeste",
            "Santa Branca",
            "Santa Clara d’Oeste",
            "Santa Cruz da Conceição",
            "Santa Cruz da Esperança",
            "Santa Cruz das Palmeiras",
            "Santa Cruz do Rio Pardo",
            "Santa Ernestina",
            "Santa Fé do Sul",
            "Santa Gertrudes",
            "Santa Isabel",
            "Santa Lúcia",
            "Santa Maria da Serra",
            "Santa Mercedes",
            "Santa Rita do Passa-Quatro",
            "Santa Rita d’Oeste",
            "Santa Rosa de Viterbo",
            "Santa Salete",
            "Santana da Ponte Pensa",
            "Santana de Parnaíba",
            "Santo Anastácio",
            "Santo André",
            "Santo Antônio da Alegria",
            "Santo Antônio de Posse",
            "Santo Antônio do Aracanguá",
            "Santo Antônio do Jardim",
            "Santo Antônio do Pinhal",
            "Santo Expedito",
            "Santópolis do Aguapeí",
            "Santos",
            "São Bento do Sapucaí",
            "São Bernardo do Campo",
            "São Caetano do Sul",
            "São Carlos",
            "São Francisco",
            "São João da Boa Vista",
            "São João das Duas Pontes",
            "São João de Iracema",
            "São João do Pau d’Alho",
            "São Joaquim da Barra",
            "São José da Bela Vista",
            "São José do Barreiro",
            "São José do Rio Pardo",
            "São José do Rio Preto",
            "São José dos Campos",
            "São Lourenço da Serra",
            "São Luiz do Paraitinga",
            "São Manuel",
            "São Miguel Arcanjo",
            "São Paulo",
            "São Pedro",
            "São Pedro do Turvo",
            "São Roque",
            "São Sebastião",
            "São Sebastião da Grama",
            "São Simão",
            "São Vicente",
            "Sarapuí",
            "Sarutaiá",
            "Sebastianópolis do Sul",
            "Serra Azul",
            "Tabapuã",
            "Tabatinga",
            "Taboão da Serra",
            "Taciba",
            "Trabiju",
            "Tremembé",
            "Três Fronteiras",
            "Tuiuti",
            "Tupã",
            "Tupi Paulista",
            "Turiúba",
            "Turmalina",
            "Taguaí",
            "Taiaçu",
            "Taiúva",
            "Tambaú",
            "Tanabi",
            "Tapiraí",
            "Tapiratiba",
            "Taquaral",
            "Taquaritinga",
            "Taquarituba",
            "Taquarivaí",
            "Tarabai",
            "Tarumã",
            "Tatuí",
            "Taubaté",
            "Tejupá",
            "Teodoro Sampaio",
            "Terra Roxa",
            "Tietê",
            "Timbo",
            "Timburi",
            "Torre de Pedra",
            "Torrinha",
            "Ubarana",
            "Ubatuba",
            "Ubirajara",
            "Uchoa",
            "União Paulista",
            "Urânia",
            "Uru",
            "Urupês",
            "Valentim Gentil",
            "Valinhos",
            "Vera Cruz",
            "Vinhedo",
            "Viradouro",
            "Vista Alegre do Alto",
            "Vitória Brasil",
            "Votorantim",
            "Votuporanga",
            "Valparaíso",
            "Vargem",
            "Vargem Grande do Sul",
            "Vargem Grande Paulista",
            "Várzea Paulista"});
            this.comboBox3.Location = new System.Drawing.Point(540, 97);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 141);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 18);
            this.label11.TabIndex = 23;
            this.label11.Text = "E-Mail:";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(79, 139);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(160, 23);
            this.textBox3.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(366, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 18);
            this.label12.TabIndex = 25;
            this.label12.Text = "RG:";
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(400, 141);
            this.maskedTextBox3.Mask = "000.000.000-0";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox3.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(522, 143);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 18);
            this.label13.TabIndex = 27;
            this.label13.Text = "CPF:";
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Location = new System.Drawing.Point(564, 142);
            this.maskedTextBox4.Mask = "000.000.000-00";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox4.TabIndex = 28;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Aquamarine;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(894, 664);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 31);
            this.button3.TabIndex = 29;
            this.button3.Text = "SALVAR";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // comboBox7
            // 
            this.comboBox7.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "@hotmail.com",
            "@gmail.com",
            "@outlook.com",
            "@yahoo.com",
            "@yahoo.com.br"});
            this.comboBox7.Location = new System.Drawing.Point(244, 138);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(102, 26);
            this.comboBox7.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 18);
            this.label2.TabIndex = 35;
            this.label2.Text = "Pressão Arterial:";
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.Location = new System.Drawing.Point(153, 196);
            this.maskedTextBox5.Mask = "000 mmHg X 00 mmHg";
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(129, 20);
            this.maskedTextBox5.TabIndex = 36;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(795, 196);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 18);
            this.label14.TabIndex = 37;
            this.label14.Text = "Alergia?\r\n";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Sim",
            "Não"});
            this.comboBox8.Location = new System.Drawing.Point(867, 196);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(72, 21);
            this.comboBox8.TabIndex = 38;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(795, 220);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(126, 18);
            this.label15.TabIndex = 39;
            this.label15.Text = "Se Sim, Quais?";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(798, 239);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(208, 134);
            this.textBox4.TabIndex = 40;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(327, 195);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(115, 18);
            this.label16.TabIndex = 41;
            this.label16.Text = "Temperatura:";
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.Location = new System.Drawing.Point(440, 195);
            this.maskedTextBox6.Mask = "00.0º ";
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(49, 20);
            this.maskedTextBox6.TabIndex = 42;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(524, 195);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(173, 18);
            this.label17.TabIndex = 43;
            this.label17.Text = "Frequência Cardíaca:";
            // 
            // maskedTextBox7
            // 
            this.maskedTextBox7.Location = new System.Drawing.Point(698, 195);
            this.maskedTextBox7.Mask = "000 BPM";
            this.maskedTextBox7.Name = "maskedTextBox7";
            this.maskedTextBox7.Size = new System.Drawing.Size(77, 20);
            this.maskedTextBox7.TabIndex = 44;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(289, 12);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 18);
            this.label18.TabIndex = 45;
            this.label18.Text = "Hora:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker2.Location = new System.Drawing.Point(342, 12);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(69, 21);
            this.dateTimePicker2.TabIndex = 46;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(15, 242);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(87, 18);
            this.label19.TabIndex = 47;
            this.label19.Text = "Vómitos? ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(15, 270);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(182, 18);
            this.label20.TabIndex = 48;
            this.label20.Text = "Problemas Recentes? ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(15, 301);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(128, 18);
            this.label21.TabIndex = 49;
            this.label21.Text = "Dores Severas?";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(15, 333);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(151, 18);
            this.label22.TabIndex = 50;
            this.label22.Text = "Dores Moderadas?\r\n";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(15, 430);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(131, 18);
            this.label23.TabIndex = 51;
            this.label23.Text = "Pulso Anormal?";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(366, 299);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(137, 18);
            this.label24.TabIndex = 52;
            this.label24.Text = "Dispneia Aguda?";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(15, 397);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(151, 18);
            this.label25.TabIndex = 53;
            this.label25.Text = "Dores Pleuríticas?\r\n";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(366, 240);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(107, 18);
            this.label26.TabIndex = 54;
            this.label26.Text = "Em Choque?\r\n";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(366, 268);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(214, 18);
            this.label27.TabIndex = 55;
            this.label27.Text = "Problemas na Respiração?";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(15, 363);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(154, 18);
            this.label28.TabIndex = 56;
            this.label28.Text = "Dores Precordiais?\r\n";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(366, 331);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(79, 18);
            this.label29.TabIndex = 57;
            this.label29.Text = "Calafrio?";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(15, 475);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(345, 18);
            this.label30.TabIndex = 58;
            this.label30.Text = "Observações e Acréscimos de Informações:\r\n";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(18, 496);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(568, 137);
            this.textBox5.TabIndex = 59;
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.Location = new System.Drawing.Point(71, 97);
            this.maskedTextBox8.Mask = "000";
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(41, 20);
            this.maskedTextBox8.TabIndex = 60;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.VomitoS);
            this.panel2.Location = new System.Drawing.Point(193, 237);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(124, 25);
            this.panel2.TabIndex = 61;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(59, 4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(49, 18);
            this.radioButton2.TabIndex = 62;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Não\r\n";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // VomitoS
            // 
            this.VomitoS.AutoSize = true;
            this.VomitoS.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VomitoS.Location = new System.Drawing.Point(8, 4);
            this.VomitoS.Name = "VomitoS";
            this.VomitoS.Size = new System.Drawing.Size(50, 18);
            this.VomitoS.TabIndex = 62;
            this.VomitoS.TabStop = true;
            this.VomitoS.Text = "Sim";
            this.VomitoS.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.radioButton1);
            this.panel3.Controls.Add(this.ProbRecent);
            this.panel3.Location = new System.Drawing.Point(193, 268);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(124, 25);
            this.panel3.TabIndex = 63;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(59, 4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(49, 18);
            this.radioButton1.TabIndex = 62;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Não\r\n";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // ProbRecent
            // 
            this.ProbRecent.AutoSize = true;
            this.ProbRecent.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProbRecent.Location = new System.Drawing.Point(8, 4);
            this.ProbRecent.Name = "ProbRecent";
            this.ProbRecent.Size = new System.Drawing.Size(50, 18);
            this.ProbRecent.TabIndex = 62;
            this.ProbRecent.TabStop = true;
            this.ProbRecent.Text = "Sim";
            this.ProbRecent.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButton3);
            this.panel4.Controls.Add(this.dorseve);
            this.panel4.Location = new System.Drawing.Point(193, 299);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(124, 25);
            this.panel4.TabIndex = 64;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(59, 4);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(49, 18);
            this.radioButton3.TabIndex = 62;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Não\r\n";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // dorseve
            // 
            this.dorseve.AutoSize = true;
            this.dorseve.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dorseve.Location = new System.Drawing.Point(8, 4);
            this.dorseve.Name = "dorseve";
            this.dorseve.Size = new System.Drawing.Size(50, 18);
            this.dorseve.TabIndex = 62;
            this.dorseve.TabStop = true;
            this.dorseve.Text = "Sim";
            this.dorseve.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButton4);
            this.panel5.Controls.Add(this.Dormord);
            this.panel5.Location = new System.Drawing.Point(193, 333);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(124, 25);
            this.panel5.TabIndex = 65;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.Location = new System.Drawing.Point(59, 4);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(49, 18);
            this.radioButton4.TabIndex = 62;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Não\r\n";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // Dormord
            // 
            this.Dormord.AutoSize = true;
            this.Dormord.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dormord.Location = new System.Drawing.Point(8, 4);
            this.Dormord.Name = "Dormord";
            this.Dormord.Size = new System.Drawing.Size(50, 18);
            this.Dormord.TabIndex = 62;
            this.Dormord.TabStop = true;
            this.Dormord.Text = "Sim";
            this.Dormord.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButton5);
            this.panel6.Controls.Add(this.Dorprec);
            this.panel6.Location = new System.Drawing.Point(193, 364);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(124, 25);
            this.panel6.TabIndex = 66;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.Location = new System.Drawing.Point(59, 4);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(49, 18);
            this.radioButton5.TabIndex = 62;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Não\r\n";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // Dorprec
            // 
            this.Dorprec.AutoSize = true;
            this.Dorprec.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dorprec.Location = new System.Drawing.Point(8, 4);
            this.Dorprec.Name = "Dorprec";
            this.Dorprec.Size = new System.Drawing.Size(50, 18);
            this.Dorprec.TabIndex = 62;
            this.Dorprec.TabStop = true;
            this.Dorprec.Text = "Sim";
            this.Dorprec.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.radioButton6);
            this.panel7.Controls.Add(this.Dorpleu);
            this.panel7.Location = new System.Drawing.Point(193, 395);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(124, 25);
            this.panel7.TabIndex = 67;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton6.Location = new System.Drawing.Point(59, 4);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(49, 18);
            this.radioButton6.TabIndex = 62;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Não\r\n";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // Dorpleu
            // 
            this.Dorpleu.AutoSize = true;
            this.Dorpleu.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dorpleu.Location = new System.Drawing.Point(8, 4);
            this.Dorpleu.Name = "Dorpleu";
            this.Dorpleu.Size = new System.Drawing.Size(50, 18);
            this.Dorpleu.TabIndex = 62;
            this.Dorpleu.TabStop = true;
            this.Dorpleu.Text = "Sim";
            this.Dorpleu.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.radioButton7);
            this.panel8.Controls.Add(this.Pulso);
            this.panel8.Location = new System.Drawing.Point(193, 426);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(124, 25);
            this.panel8.TabIndex = 65;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton7.Location = new System.Drawing.Point(59, 4);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(49, 18);
            this.radioButton7.TabIndex = 62;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Não\r\n";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // Pulso
            // 
            this.Pulso.AutoSize = true;
            this.Pulso.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pulso.Location = new System.Drawing.Point(8, 4);
            this.Pulso.Name = "Pulso";
            this.Pulso.Size = new System.Drawing.Size(50, 18);
            this.Pulso.TabIndex = 62;
            this.Pulso.TabStop = true;
            this.Pulso.Text = "Sim";
            this.Pulso.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.radioButton8);
            this.panel9.Controls.Add(this.Choque);
            this.panel9.Location = new System.Drawing.Point(586, 234);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(113, 25);
            this.panel9.TabIndex = 68;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(59, 4);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(49, 18);
            this.radioButton8.TabIndex = 62;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Não\r\n";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // Choque
            // 
            this.Choque.AutoSize = true;
            this.Choque.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Choque.Location = new System.Drawing.Point(8, 4);
            this.Choque.Name = "Choque";
            this.Choque.Size = new System.Drawing.Size(50, 18);
            this.Choque.TabIndex = 62;
            this.Choque.TabStop = true;
            this.Choque.Text = "Sim";
            this.Choque.UseVisualStyleBackColor = true;
            this.Choque.CheckedChanged += new System.EventHandler(this.Choque_CheckedChanged);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.radioButton9);
            this.panel10.Controls.Add(this.Respi);
            this.panel10.Location = new System.Drawing.Point(586, 263);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(113, 25);
            this.panel10.TabIndex = 69;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton9.Location = new System.Drawing.Point(59, 4);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(49, 18);
            this.radioButton9.TabIndex = 62;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Não\r\n";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // Respi
            // 
            this.Respi.AutoSize = true;
            this.Respi.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Respi.Location = new System.Drawing.Point(8, 4);
            this.Respi.Name = "Respi";
            this.Respi.Size = new System.Drawing.Size(50, 18);
            this.Respi.TabIndex = 62;
            this.Respi.TabStop = true;
            this.Respi.Text = "Sim";
            this.Respi.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.radioButton10);
            this.panel11.Controls.Add(this.Dispneia);
            this.panel11.Location = new System.Drawing.Point(586, 294);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(113, 25);
            this.panel11.TabIndex = 70;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(59, 4);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(49, 18);
            this.radioButton10.TabIndex = 62;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "Não\r\n";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // Dispneia
            // 
            this.Dispneia.AutoSize = true;
            this.Dispneia.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dispneia.Location = new System.Drawing.Point(8, 4);
            this.Dispneia.Name = "Dispneia";
            this.Dispneia.Size = new System.Drawing.Size(50, 18);
            this.Dispneia.TabIndex = 62;
            this.Dispneia.TabStop = true;
            this.Dispneia.Text = "Sim";
            this.Dispneia.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.radioButton11);
            this.panel12.Controls.Add(this.Cfrio);
            this.panel12.Location = new System.Drawing.Point(586, 324);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(113, 25);
            this.panel12.TabIndex = 68;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton11.Location = new System.Drawing.Point(59, 4);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(49, 18);
            this.radioButton11.TabIndex = 62;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Não\r\n";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // Cfrio
            // 
            this.Cfrio.AutoSize = true;
            this.Cfrio.Font = new System.Drawing.Font("Bookman Old Style", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cfrio.Location = new System.Drawing.Point(8, 4);
            this.Cfrio.Name = "Cfrio";
            this.Cfrio.Size = new System.Drawing.Size(50, 18);
            this.Cfrio.TabIndex = 62;
            this.Cfrio.TabStop = true;
            this.Cfrio.Text = "Sim";
            this.Cfrio.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(746, 426);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(191, 18);
            this.label31.TabIndex = 71;
            this.label31.Text = "Situação do Paciente é:\r\n";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.maskedTextBox9);
            this.panel1.Controls.Add(this.NDURG);
            this.panel1.Controls.Add(this.PCURG);
            this.panel1.Controls.Add(this.URG);
            this.panel1.Controls.Add(this.MTURG);
            this.panel1.Controls.Add(this.ERME);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.maskedTextBox8);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.maskedTextBox7);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.maskedTextBox6);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.comboBox8);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.maskedTextBox5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.comboBox7);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.maskedTextBox4);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.maskedTextBox3);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.maskedTextBox2);
            this.panel1.Controls.Add(this.maskedTextBox1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(12);
            this.panel1.Size = new System.Drawing.Size(1018, 704);
            this.panel1.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Aquamarine;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(772, 664);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(116, 31);
            this.button4.TabIndex = 89;
            this.button4.Text = "LIMPAR";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::InicioTriagem.Properties.Resources.diagnostics_161140_1280;
            this.pictureBox1.Location = new System.Drawing.Point(880, 57);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(123, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 88;
            this.pictureBox1.TabStop = false;
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.Location = new System.Drawing.Point(308, 97);
            this.maskedTextBox9.Mask = "00/ 00/ 0000";
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(105, 20);
            this.maskedTextBox9.TabIndex = 87;
            // 
            // NDURG
            // 
            this.NDURG.AutoSize = true;
            this.NDURG.Location = new System.Drawing.Point(880, 607);
            this.NDURG.Name = "NDURG";
            this.NDURG.Size = new System.Drawing.Size(14, 13);
            this.NDURG.TabIndex = 86;
            this.NDURG.TabStop = true;
            this.NDURG.UseVisualStyleBackColor = true;
            // 
            // PCURG
            // 
            this.PCURG.AutoSize = true;
            this.PCURG.Location = new System.Drawing.Point(898, 571);
            this.PCURG.Name = "PCURG";
            this.PCURG.Size = new System.Drawing.Size(14, 13);
            this.PCURG.TabIndex = 85;
            this.PCURG.TabStop = true;
            this.PCURG.UseVisualStyleBackColor = true;
            // 
            // URG
            // 
            this.URG.AutoSize = true;
            this.URG.Location = new System.Drawing.Point(839, 536);
            this.URG.Name = "URG";
            this.URG.Size = new System.Drawing.Size(14, 13);
            this.URG.TabIndex = 84;
            this.URG.TabStop = true;
            this.URG.UseVisualStyleBackColor = true;
            // 
            // MTURG
            // 
            this.MTURG.AutoSize = true;
            this.MTURG.Location = new System.Drawing.Point(898, 503);
            this.MTURG.Name = "MTURG";
            this.MTURG.Size = new System.Drawing.Size(14, 13);
            this.MTURG.TabIndex = 83;
            this.MTURG.TabStop = true;
            this.MTURG.UseVisualStyleBackColor = true;
            // 
            // ERME
            // 
            this.ERME.AutoSize = true;
            this.ERME.Location = new System.Drawing.Point(865, 464);
            this.ERME.Name = "ERME";
            this.ERME.Size = new System.Drawing.Size(14, 13);
            this.ERME.TabIndex = 82;
            this.ERME.TabStop = true;
            this.ERME.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(746, 604);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(126, 18);
            this.label36.TabIndex = 81;
            this.label36.Text = "NÃO URGENTE";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(746, 568);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(148, 18);
            this.label35.TabIndex = 80;
            this.label35.Text = "POUCO URGENTE";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(746, 533);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(87, 18);
            this.label34.TabIndex = 79;
            this.label34.Text = "URGENTE";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(746, 500);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(147, 18);
            this.label33.TabIndex = 78;
            this.label33.Text = "MUITO URGENTE";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(746, 464);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(119, 18);
            this.label32.TabIndex = 77;
            this.label32.Text = "EMERGÊNCIA";
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = global::InicioTriagem.Properties.Resources.unnamed1;
            this.button2.Location = new System.Drawing.Point(985, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 25);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(1042, 728);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MaskedTextBox maskedTextBox7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton VomitoS;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton ProbRecent;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton dorseve;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton Dormord;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton Dorprec;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton Dorpleu;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton Pulso;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton Choque;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton Respi;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton Dispneia;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton Cfrio;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton NDURG;
        private System.Windows.Forms.RadioButton PCURG;
        private System.Windows.Forms.RadioButton URG;
        private System.Windows.Forms.RadioButton MTURG;
        private System.Windows.Forms.RadioButton ERME;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button4;
    }
}